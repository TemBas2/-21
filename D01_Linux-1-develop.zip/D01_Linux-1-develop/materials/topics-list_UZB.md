Salom, School 21 ishtirokchisi!

Sizga osonroq bo’lishi uchun biz ushbu loyihani bajarishda alohida e'tibor berishingiz kerak bo'lgan mavzular ro'yxatini tayyorladik:

- buyruq qatori bilan ishlash;
- Linux operatsion tizimini sozlash;
- superfoydalanuvchi huquqlari;
- `apt` yordamida ilovalarni o'rnatish;
- utilitalardan foydalanish (top/htop/df/du/ncdu). 

Endi, siz loyihada talab qilinadigan mavzular, bilimlar ro'yxatini bilganingizdan so'ng, bemalol o'rganishni boshlashingiz mumkin.

